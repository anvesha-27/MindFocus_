# MindFocus - Mental Health & Productivity Suite

## Overview

MindFocus is a Progressive Web Application (PWA) suite that combines mental health enhancement with productivity techniques. The platform includes:

1. **Pomodoro Timer** (index.html) - Main productivity app with timer, motivational quotes, and mindfulness features
2. **Kids To-Do List** (todo.html) - A colorful, beginner-friendly task management app designed specifically for children

Both apps are built as client-side only applications, leveraging modern web technologies to deliver seamless, offline-capable experiences focused on mental health and productivity.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Pure Client-Side Application**: Built with vanilla HTML, CSS, and JavaScript without any backend dependencies
- **Progressive Web App (PWA)**: Implements PWA standards with manifest.json and service worker for offline functionality and app-like experience
- **Component-Based JavaScript**: Uses ES6 classes to organize functionality, with the main `PomodoroTimer` class managing application state
- **Responsive Design**: CSS Grid and Flexbox layout with mobile-first approach using CSS custom properties for consistent theming
- **Icon System**: Integrates Feather Icons for consistent UI iconography

### Timer & State Management
- **Local State Management**: All application state is managed in-memory with localStorage persistence for settings and statistics
- **Timer Implementation**: Uses JavaScript's `setInterval` for countdown functionality with proper cleanup and pause/resume capabilities
- **Audio Notifications**: Integrates Web Audio API for timer completion sounds and notifications

### Data Persistence
- **Browser Storage**: Utilizes localStorage for persisting user settings, session statistics, and motivational quotes
- **No External Database**: All data is stored locally in the user's browser for privacy and offline functionality

### Performance & Caching
- **Service Worker**: Implements comprehensive caching strategy for offline functionality
- **Resource Optimization**: Preloads critical resources and uses efficient caching patterns
- **Font Loading**: Optimized font loading with preconnect hints for Google Fonts

### User Experience
- **Accessibility**: Implements proper ARIA labels and semantic HTML structure
- **Visual Feedback**: Circular progress indicators and smooth transitions for engaging user experience
- **Theming**: Consistent color palette focused on calming colors (blues, greens, lavender) for mental health emphasis

## External Dependencies

### CDN Resources
- **Google Fonts**: Inter font family for consistent typography
- **Feather Icons**: Lightweight icon library loaded via CDN
- **Tone.js**: Web Audio library for sound synthesis and audio notifications (referenced in service worker)

### Web APIs
- **Service Worker API**: For PWA functionality and offline caching
- **Web Audio API**: For generating notification sounds and audio feedback
- **Local Storage API**: For persisting user data and preferences
- **Notifications API**: For system notifications when timer completes

### Browser Features
- **PWA Manifest**: Enables installation and app-like behavior on mobile devices
- **CSS Custom Properties**: For dynamic theming and consistent design system
- **ES6+ Features**: Modern JavaScript features including classes, arrow functions, and async/await

## Kids To-Do List App (New Feature - Added January 2025)

### Purpose
A beginner-friendly task management application specifically designed for children, featuring:
- Colorful, animated interface with fun graphics
- Simple add/remove task functionality
- Visual feedback and celebration effects
- Kid-safe input validation
- Local storage for task persistence

### Technical Implementation
- **Files**: todo.html, todo-styles.css, todo-script.js
- **Design**: Bright gradient backgrounds, Comic Sans font, emoji icons
- **Animations**: CSS keyframes for bouncing, floating elements, and celebration effects
- **Sound Effects**: Web Audio API for interactive feedback
- **Storage**: localStorage for task persistence
- **Validation**: Input sanitization and length limits for child safety

### Features
- Add tasks with colorful "Add Task" button
- Remove tasks with confirmation dialog
- Check/uncheck tasks with completion animations
- Task counter showing progress
- Floating decorative elements (stars, hearts)
- Responsive design for mobile devices
- Success messages and particle effects

### Access
- Main app: `/` (index.html)
- Kids to-do list: `/todo.html`