class PomodoroTimer {
    constructor() {
        // Timer state
        this.isRunning = false;
        this.isPaused = false;
        this.currentMode = 'focus'; // 'focus' or 'break'
        this.currentSession = 1;
        this.timeLeft = 25 * 60; // 25 minutes in seconds
        this.totalTime = 25 * 60;
        this.timer = null;
        
        // Settings
        this.settings = {
            focusTime: 25,
            breakTime: 5,
            soundEnabled: true,
            autoStartBreaks: true
        };
        
        // Audio context for notifications
        this.audioContext = null;
        this.toneSynth = null;
        
        // DOM elements
        this.initializeElements();
        
        // Load data and initialize
        this.loadSettings();
        this.loadStats();
        this.loadQuotes();
        this.initializeEventListeners();
        this.initializeAudio();
        this.updateDisplay();
        this.displayRandomQuote();
        
        // Initialize feather icons
        this.initializeIcons();
    }
    
    initializeElements() {
        // Timer elements
        this.timerTimeEl = document.getElementById('timerTime');
        this.timerModeEl = document.getElementById('timerMode');
        this.sessionCounterEl = document.getElementById('sessionCounter');
        this.startPauseBtn = document.getElementById('startPauseBtn');
        this.resetBtn = document.getElementById('resetBtn');
        this.progressBar = document.querySelector('.progress-bar');
        this.timerSection = document.querySelector('.timer-section');
        
        // Quote elements
        this.quoteTextEl = document.getElementById('quoteText');
        this.quoteAuthorEl = document.getElementById('quoteAuthor');
        this.refreshQuoteBtn = document.getElementById('refreshQuoteBtn');
        
        // Stats elements
        this.totalSessionsEl = document.getElementById('totalSessions');
        this.totalMinutesEl = document.getElementById('totalMinutes');
        this.todaySessionsEl = document.getElementById('todaySessions');
        
        // Settings elements
        this.settingsBtn = document.getElementById('settingsBtn');
        this.settingsPanel = document.getElementById('settingsPanel');
        this.closeSettingsBtn = document.getElementById('closeSettings');
        this.overlay = document.getElementById('overlay');
        
        this.focusTimeSlider = document.getElementById('focusTime');
        this.breakTimeSlider = document.getElementById('breakTime');
        this.focusTimeValue = document.getElementById('focusTimeValue');
        this.breakTimeValue = document.getElementById('breakTimeValue');
        this.soundEnabledCheckbox = document.getElementById('soundEnabled');
        this.autoStartBreaksCheckbox = document.getElementById('autoStartBreaks');
    }
    
    initializeEventListeners() {
        // Timer controls
        this.startPauseBtn.addEventListener('click', () => this.toggleTimer());
        this.resetBtn.addEventListener('click', () => this.resetTimer());
        
        // Quote refresh
        this.refreshQuoteBtn.addEventListener('click', () => this.displayRandomQuote());
        
        // Settings panel
        this.settingsBtn.addEventListener('click', () => this.openSettings());
        this.closeSettingsBtn.addEventListener('click', () => this.closeSettings());
        this.overlay.addEventListener('click', () => this.closeSettings());
        
        // Settings controls
        this.focusTimeSlider.addEventListener('input', (e) => {
            this.settings.focusTime = parseInt(e.target.value);
            this.focusTimeValue.textContent = e.target.value;
            this.saveSettings();
            if (this.currentMode === 'focus' && !this.isRunning) {
                this.resetTimer();
            }
        });
        
        this.breakTimeSlider.addEventListener('input', (e) => {
            this.settings.breakTime = parseInt(e.target.value);
            this.breakTimeValue.textContent = e.target.value;
            this.saveSettings();
            if (this.currentMode === 'break' && !this.isRunning) {
                this.resetTimer();
            }
        });
        
        this.soundEnabledCheckbox.addEventListener('change', (e) => {
            this.settings.soundEnabled = e.target.checked;
            this.saveSettings();
        });
        
        this.autoStartBreaksCheckbox.addEventListener('change', (e) => {
            this.settings.autoStartBreaks = e.target.checked;
            this.saveSettings();
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT') return;
            
            switch(e.code) {
                case 'Space':
                    e.preventDefault();
                    this.toggleTimer();
                    break;
                case 'KeyR':
                    e.preventDefault();
                    this.resetTimer();
                    break;
                case 'KeyQ':
                    e.preventDefault();
                    this.displayRandomQuote();
                    break;
            }
        });
        
        // Handle visibility change (battery optimization)
        document.addEventListener('visibilitychange', () => {
            if (document.hidden && this.isRunning) {
                this.lastVisibilityChange = Date.now();
            } else if (!document.hidden && this.isRunning && this.lastVisibilityChange) {
                const elapsed = Math.floor((Date.now() - this.lastVisibilityChange) / 1000);
                this.timeLeft = Math.max(0, this.timeLeft - elapsed);
                this.updateDisplay();
                if (this.timeLeft <= 0) {
                    this.completeSession();
                }
            }
        });
    }
    
    initializeAudio() {
        try {
            // Initialize Tone.js if available
            if (typeof Tone !== 'undefined') {
                this.toneSynth = new Tone.Synth().toDestination();
            } else {
                console.warn('Tone.js not loaded, audio notifications will be limited');
            }
        } catch (error) {
            console.warn('Audio initialization failed:', error);
        }
    }
    
    initializeIcons() {
        // Initialize feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
    }
    
    async playNotificationSound() {
        if (!this.settings.soundEnabled) return;
        
        try {
            if (this.toneSynth && typeof Tone !== 'undefined' && Tone.context.state === 'running') {
                // Play a pleasant notification sound
                await this.toneSynth.triggerAttackRelease('C5', '0.2');
                await new Promise(resolve => setTimeout(resolve, 300));
                await this.toneSynth.triggerAttackRelease('E5', '0.2');
                await new Promise(resolve => setTimeout(resolve, 300));
                await this.toneSynth.triggerAttackRelease('G5', '0.4');
            } else {
                // Fallback: use a simple beep or vibration
                if ('vibrate' in navigator) {
                    navigator.vibrate([200, 100, 200]);
                }
                console.log('Timer completed! (Sound not available)');
            }
        } catch (error) {
            console.warn('Failed to play notification sound:', error);
            // Fallback: use vibration if available
            if ('vibrate' in navigator) {
                navigator.vibrate([200, 100, 200]);
            }
        }
    }
    
    toggleTimer() {
        console.log('Toggle timer called. Current state - isRunning:', this.isRunning, 'isPaused:', this.isPaused);
        if (this.isRunning) {
            this.pauseTimer();
        } else {
            this.startTimer();
        }
    }
    
    async startTimer() {
        // Start audio context if needed
        try {
            if (typeof Tone !== 'undefined' && Tone.context.state !== 'running') {
                await Tone.start();
            }
        } catch (error) {
            console.warn('Tone.js not available or failed to start:', error);
        }
        
        this.isRunning = true;
        this.isPaused = false;
        this.timerSection.classList.add('active');
        
        this.updateStartPauseButton();
        
        this.timer = setInterval(() => {
            this.timeLeft--;
            this.updateDisplay();
            // Timer tick
            
            if (this.timeLeft <= 0) {
                console.log('Timer reached zero, completing session');
                this.completeSession();
            }
        }, 1000);
    }
    
    pauseTimer() {
        this.isRunning = false;
        this.isPaused = true;
        this.timerSection.classList.remove('active');
        
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        
        this.updateStartPauseButton();
    }
    
    resetTimer() {
        this.isRunning = false;
        this.isPaused = false;
        this.timerSection.classList.remove('active');
        
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        
        if (this.currentMode === 'focus') {
            this.timeLeft = this.settings.focusTime * 60;
            this.totalTime = this.settings.focusTime * 60;
        } else {
            this.timeLeft = this.settings.breakTime * 60;
            this.totalTime = this.settings.breakTime * 60;
        }
        
        this.updateDisplay();
        this.updateStartPauseButton();
    }
    
    completeSession() {
        this.isRunning = false;
        this.timerSection.classList.remove('active');
        
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        
        // Play notification sound
        this.playNotificationSound();
        
        if (this.currentMode === 'focus') {
            // Focus session completed
            this.incrementStats();
            this.currentMode = 'break';
            this.timeLeft = this.settings.breakTime * 60;
            this.totalTime = this.settings.breakTime * 60;
            
            // Show notification
            this.showNotification('Great job! Time for a break.');
            
            // Auto-start break if enabled
            if (this.settings.autoStartBreaks) {
                setTimeout(() => this.startTimer(), 1000);
            }
        } else {
            // Break completed
            this.currentMode = 'focus';
            this.currentSession++;
            this.timeLeft = this.settings.focusTime * 60;
            this.totalTime = this.settings.focusTime * 60;
            
            // Show notification
            this.showNotification('Break is over! Ready to focus?');
            
            // Get new motivational quote
            this.displayRandomQuote();
        }
        
        this.updateDisplay();
        this.updateStartPauseButton();
        console.log('Timer completed. Mode:', this.currentMode, 'Session:', this.currentSession);
    }
    
    updateDisplay() {
        // Update timer display
        const minutes = Math.floor(this.timeLeft / 60);
        const seconds = this.timeLeft % 60;
        this.timerTimeEl.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        // Update mode display
        this.timerModeEl.textContent = this.currentMode === 'focus' ? 'Focus Time' : 'Break Time';
        
        // Update session counter
        this.sessionCounterEl.textContent = `Session ${this.currentSession}`;
        
        // Update progress bar
        const progress = ((this.totalTime - this.timeLeft) / this.totalTime) * 754; // 754 is the full circumference
        this.progressBar.style.strokeDashoffset = 754 - progress;
        
        // Update progress bar color based on mode
        if (this.currentMode === 'focus') {
            this.progressBar.style.stroke = '#0EA5E9'; // secondary-blue
        } else {
            this.progressBar.style.stroke = '#10B981'; // accent-green
        }
        
        // Update page title with timer
        document.title = `${this.timerTimeEl.textContent} - MindFocus`;
    }
    
    updateStartPauseButton() {
        const icon = this.startPauseBtn.querySelector('i');
        const span = this.startPauseBtn.querySelector('span');
        
        if (this.isRunning) {
            icon.setAttribute('data-feather', 'pause');
            span.textContent = 'Pause';
            this.startPauseBtn.setAttribute('aria-label', 'Pause timer');
        } else {
            icon.setAttribute('data-feather', 'play');
            span.textContent = this.isPaused ? 'Resume' : 'Start';
            this.startPauseBtn.setAttribute('aria-label', this.isPaused ? 'Resume timer' : 'Start timer');
        }
        
        // Re-initialize feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
    }
    
    showNotification(message) {
        // Show browser notification if permission is granted
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('MindFocus', {
                body: message,
                icon: 'icons/icon-192.svg',
                badge: 'icons/icon-192.svg'
            });
        } else if ('Notification' in window && Notification.permission !== 'denied') {
            // Request permission
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    new Notification('MindFocus', {
                        body: message,
                        icon: 'icons/icon-192.svg',
                        badge: 'icons/icon-192.svg'
                    });
                }
            });
        }
        
        // Vibrate if supported (mobile)
        if ('vibrate' in navigator) {
            navigator.vibrate([200, 100, 200]);
        }
    }
    
    // Settings management
    openSettings() {
        this.settingsPanel.classList.add('open');
        this.overlay.classList.add('show');
        this.settingsPanel.setAttribute('aria-hidden', 'false');
        this.overlay.setAttribute('aria-hidden', 'false');
        
        // Focus management
        this.closeSettingsBtn.focus();
    }
    
    closeSettings() {
        this.settingsPanel.classList.remove('open');
        this.overlay.classList.remove('show');
        this.settingsPanel.setAttribute('aria-hidden', 'true');
        this.overlay.setAttribute('aria-hidden', 'true');
        
        // Return focus to settings button
        this.settingsBtn.focus();
    }
    
    saveSettings() {
        localStorage.setItem('pomodoroSettings', JSON.stringify(this.settings));
    }
    
    loadSettings() {
        const saved = localStorage.getItem('pomodoroSettings');
        if (saved) {
            this.settings = { ...this.settings, ...JSON.parse(saved) };
        }
        
        // Update UI
        this.focusTimeSlider.value = this.settings.focusTime;
        this.breakTimeSlider.value = this.settings.breakTime;
        this.focusTimeValue.textContent = this.settings.focusTime;
        this.breakTimeValue.textContent = this.settings.breakTime;
        this.soundEnabledCheckbox.checked = this.settings.soundEnabled;
        this.autoStartBreaksCheckbox.checked = this.settings.autoStartBreaks;
        
        // Update timer if not running
        if (!this.isRunning) {
            this.resetTimer();
        }
    }
    
    // Stats management
    incrementStats() {
        const stats = this.getStats();
        const today = new Date().toDateString();
        
        stats.totalSessions++;
        stats.totalMinutes += this.settings.focusTime;
        
        if (stats.lastSessionDate !== today) {
            stats.todaySessions = 1;
            stats.lastSessionDate = today;
        } else {
            stats.todaySessions++;
        }
        
        this.saveStats(stats);
        this.updateStatsDisplay(stats);
    }
    
    getStats() {
        const defaultStats = {
            totalSessions: 0,
            totalMinutes: 0,
            todaySessions: 0,
            lastSessionDate: null
        };
        
        const saved = localStorage.getItem('pomodoroStats');
        return saved ? { ...defaultStats, ...JSON.parse(saved) } : defaultStats;
    }
    
    saveStats(stats) {
        localStorage.setItem('pomodoroStats', JSON.stringify(stats));
    }
    
    loadStats() {
        const stats = this.getStats();
        const today = new Date().toDateString();
        
        // Reset today's sessions if it's a new day
        if (stats.lastSessionDate !== today) {
            stats.todaySessions = 0;
        }
        
        this.updateStatsDisplay(stats);
    }
    
    updateStatsDisplay(stats) {
        this.totalSessionsEl.textContent = stats.totalSessions;
        this.totalMinutesEl.textContent = stats.totalMinutes;
        this.todaySessionsEl.textContent = stats.todaySessions;
    }
    
    // Quotes management
    loadQuotes() {
        this.quotes = [
            { text: "The mind is everything. What you think you become.", author: "Buddha" },
            { text: "Peace comes from within. Do not seek it without.", author: "Buddha" },
            { text: "You have power over your mind - not outside events. Realize this, and you will find strength.", author: "Marcus Aurelius" },
            { text: "The present moment is the only time over which we have dominion.", author: "Thích Nhất Hạnh" },
            { text: "Mindfulness is a way of befriending ourselves and our experience.", author: "Jon Kabat-Zinn" },
            { text: "Wherever you are, be there totally. If you find your here and now intolerable, you have options: remove yourself from the situation, change it, or accept it totally.", author: "Eckhart Tolle" },
            { text: "The best way to take care of the future is to take care of the present moment.", author: "Thích Nhất Hạnh" },
            { text: "Feelings come and go like clouds in a windy sky. Conscious breathing is my anchor.", author: "Thích Nhất Hạnh" },
            { text: "You are not your thoughts. You are the observer of your thoughts.", author: "Eckhart Tolle" },
            { text: "The little things? The little moments? They aren't little.", author: "Jon Kabat-Zinn" },
            { text: "Breathing in, I calm body and mind. Breathing out, I smile.", author: "Thích Nhất Hạnh" },
            { text: "Your task is not to seek for love, but merely to seek and find all the barriers within yourself that you have built against it.", author: "Rumi" },
            { text: "The cave you fear to enter holds the treasure you seek.", author: "Joseph Campbell" },
            { text: "Progress, not perfection.", author: "Anonymous" },
            { text: "You are exactly where you need to be.", author: "Anonymous" },
            { text: "Be kind to yourself. You're doing the best you can.", author: "Anonymous" },
            { text: "This too shall pass.", author: "Persian Proverb" },
            { text: "One day at a time.", author: "Anonymous" },
            { text: "Breathe in peace, breathe out stress.", author: "Anonymous" },
            { text: "Your mental health is a priority. Your happiness is essential. Your self-care is a necessity.", author: "Anonymous" }
        ];
    }
    
    displayRandomQuote() {
        if (this.quotes.length === 0) return;
        
        const randomIndex = Math.floor(Math.random() * this.quotes.length);
        const quote = this.quotes[randomIndex];
        
        // Add fade transition
        this.quoteTextEl.style.opacity = '0';
        this.quoteAuthorEl.style.opacity = '0';
        
        setTimeout(() => {
            this.quoteTextEl.textContent = quote.text;
            this.quoteAuthorEl.textContent = `— ${quote.author}`;
            
            this.quoteTextEl.style.opacity = '1';
            this.quoteAuthorEl.style.opacity = '1';
        }, 150);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing PomodoroTimer...');
    const app = new PomodoroTimer();
    
    // Make app globally accessible for debugging
    window.pomodoroApp = app;
    console.log('PomodoroTimer initialized successfully');
});

// Handle touch events for better mobile experience
document.addEventListener('touchstart', function() {}, { passive: true });
document.addEventListener('touchmove', function() {}, { passive: true });

// Prevent zoom on double tap for better UX
let lastTouchEnd = 0;
document.addEventListener('touchend', function (event) {
    const now = (new Date()).getTime();
    if (now - lastTouchEnd <= 300) {
        event.preventDefault();
    }
    lastTouchEnd = now;
}, false);

// Add CSS for smooth transitions
document.head.insertAdjacentHTML('beforeend', `
<style>
.quote-text, .quote-author {
    transition: opacity 0.3s ease;
}
</style>
`);
