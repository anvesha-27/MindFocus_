const CACHE_NAME = 'mindfocus-v1.0.0';
const urlsToCache = [
    '/',
    '/index.html',
    '/styles.css',
    '/script.js',
    '/manifest.json',
    '/icons/icon-192.svg',
    '/icons/icon-512.svg',
    'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap',
    'https://unpkg.com/feather-icons',
    'https://cdnjs.cloudflare.com/ajax/libs/tone/14.8.49/Tone.js'
];

// Install event - cache resources
self.addEventListener('install', event => {
    console.log('Service Worker installing...');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Caching app shell');
                return cache.addAll(urlsToCache.map(url => new Request(url, {
                    cache: 'reload'
                })));
            })
            .catch(error => {
                console.error('Failed to cache resources:', error);
                // Continue installation even if some resources fail to cache
                return Promise.resolve();
            })
    );
    
    // Force the waiting service worker to become the active service worker
    self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
    console.log('Service Worker activating...');
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== CACHE_NAME) {
                        console.log('Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(() => {
            // Claim control of all clients
            return self.clients.claim();
        })
    );
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', event => {
    // Skip cross-origin requests
    if (!event.request.url.startsWith(self.location.origin) && 
        !event.request.url.startsWith('https://fonts.googleapis.com') &&
        !event.request.url.startsWith('https://fonts.gstatic.com') &&
        !event.request.url.startsWith('https://unpkg.com') &&
        !event.request.url.startsWith('https://cdnjs.cloudflare.com')) {
        return;
    }
    
    event.respondWith(
        caches.match(event.request)
            .then(response => {
                // Return cached version or fetch from network
                if (response) {
                    console.log('Serving from cache:', event.request.url);
                    return response;
                }
                
                console.log('Fetching from network:', event.request.url);
                return fetch(event.request).then(response => {
                    // Don't cache if not a valid response
                    if (!response || response.status !== 200 || response.type !== 'basic') {
                        return response;
                    }
                    
                    // Clone the response since it can only be consumed once
                    const responseToCache = response.clone();
                    
                    caches.open(CACHE_NAME)
                        .then(cache => {
                            cache.put(event.request, responseToCache);
                        });
                    
                    return response;
                }).catch(error => {
                    console.error('Fetch failed:', error);
                    
                    // Return a custom offline page for navigation requests
                    if (event.request.destination === 'document') {
                        return caches.match('/index.html');
                    }
                    
                    // For other requests, return undefined to trigger browser's default handling
                    return undefined;
                });
            })
    );
});

// Handle background sync for timer completion
self.addEventListener('sync', event => {
    if (event.tag === 'timer-complete') {
        console.log('Background sync: timer-complete');
        event.waitUntil(handleTimerCompletion());
    }
});

// Handle push notifications
self.addEventListener('push', event => {
    console.log('Push notification received');
    
    const options = {
        body: event.data ? event.data.text() : 'Time to focus or take a break!',
        icon: '/icons/icon-192.svg',
        badge: '/icons/icon-192.svg',
        vibrate: [200, 100, 200],
        data: {
            dateOfArrival: Date.now(),
            primaryKey: '1'
        },
        actions: [
            {
                action: 'start',
                title: 'Start Timer',
                icon: '/icons/icon-192.svg'
            },
            {
                action: 'close',
                title: 'Close',
                icon: '/icons/icon-192.svg'
            }
        ]
    };
    
    event.waitUntil(
        self.registration.showNotification('MindFocus', options)
    );
});

// Handle notification click
self.addEventListener('notificationclick', event => {
    console.log('Notification clicked:', event.action);
    
    event.notification.close();
    
    if (event.action === 'start') {
        // Open app and start timer
        event.waitUntil(
            clients.openWindow('/?action=start')
        );
    } else if (event.action === 'close') {
        // Just close the notification
        return;
    } else {
        // Default action - open the app
        event.waitUntil(
            clients.matchAll().then(clientList => {
                for (const client of clientList) {
                    if (client.url === '/' && 'focus' in client) {
                        return client.focus();
                    }
                }
                if (clients.openWindow) {
                    return clients.openWindow('/');
                }
            })
        );
    }
});

// Handle messages from the main thread
self.addEventListener('message', event => {
    console.log('Service Worker received message:', event.data);
    
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
    
    if (event.data && event.data.type === 'GET_VERSION') {
        event.ports[0].postMessage({ version: CACHE_NAME });
    }
});

// Background timer completion handler
async function handleTimerCompletion() {
    try {
        // Get all active clients
        const clients = await self.clients.matchAll();
        
        // If app is not open, show notification
        if (clients.length === 0) {
            await self.registration.showNotification('MindFocus - Timer Complete!', {
                body: 'Your Pomodoro session is complete. Time for a break!',
                icon: '/icons/icon-192.svg',
                badge: '/icons/icon-192.svg',
                vibrate: [200, 100, 200, 100, 200],
                requireInteraction: true,
                actions: [
                    {
                        action: 'open',
                        title: 'Open App'
                    }
                ]
            });
        }
    } catch (error) {
        console.error('Error handling timer completion:', error);
    }
}

// Periodic background sync for keeping timer accurate
self.addEventListener('periodicsync', event => {
    if (event.tag === 'timer-sync') {
        console.log('Periodic sync: timer-sync');
        event.waitUntil(syncTimerState());
    }
});

async function syncTimerState() {
    try {
        // Sync timer state with any open clients
        const clients = await self.clients.matchAll();
        
        clients.forEach(client => {
            client.postMessage({
                type: 'SYNC_TIMER_STATE',
                timestamp: Date.now()
            });
        });
    } catch (error) {
        console.error('Error syncing timer state:', error);
    }
}

// Error handling
self.addEventListener('error', event => {
    console.error('Service Worker error:', event.error);
});

self.addEventListener('unhandledrejection', event => {
    console.error('Service Worker unhandled rejection:', event.reason);
});

// Installation prompt handling
let deferredPrompt;

self.addEventListener('beforeinstallprompt', event => {
    console.log('Before install prompt triggered');
    event.preventDefault();
    deferredPrompt = event;
    
    // Notify the main thread that install is available
    self.clients.matchAll().then(clients => {
        clients.forEach(client => {
            client.postMessage({
                type: 'INSTALL_AVAILABLE'
            });
        });
    });
});

// Handle app installation
self.addEventListener('appinstalled', event => {
    console.log('App installed successfully');
    deferredPrompt = null;
    
    // Notify the main thread that app was installed
    self.clients.matchAll().then(clients => {
        clients.forEach(client => {
            client.postMessage({
                type: 'APP_INSTALLED'
            });
        });
    });
});
